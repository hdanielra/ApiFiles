﻿using Contracts;
using Entities;
using Entities.Models;

namespace Repository
{
    public class SalesRepository : RepositoryBase<InMemoryContext, Sales>, ISalesRepository
    {
        public SalesRepository(InMemoryContext memoryContext)
            : base(memoryContext)
        {
        }
    }
}