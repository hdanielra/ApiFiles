﻿using Contracts;
using Entities;
using System.Threading.Tasks;

namespace Repository
{
    // to manage the 2 forms of connection, the RepositoryManager is defined 

    public class RepositoryManager : IRepositoryManager
    {

        // --------------------------------------------------------
        // the 2 ways to connect
        private InMemoryContext _memoryContext;
        // --------------------------------------------------------



        // --------------------------------------------------------
        private ISalesRepository _sales;
        // --------------------------------------------------------



        // --------------------------------------------------------
        // injection
        public RepositoryManager(InMemoryContext memoryContext)
        {
            _memoryContext = memoryContext;
        }
        // --------------------------------------------------------






        // --------------------------------------------------------
        public ISalesRepository Sales
        {
            get
            {
                if (_sales == null)
                    _sales = new SalesRepository(_memoryContext);
                return _sales;
            }
        }
        // --------------------------------------------------------











        // --------------------------------------------------------
        public async Task Save()
        {
            try
            {

                await _memoryContext.SaveChangesAsync();
            }
            catch (System.Exception ex)
            {
                System.Console.WriteLine(ex.Message);
                throw;
            }
        }
        // --------------------------------------------------------
    }
}