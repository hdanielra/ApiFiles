﻿using AutoMapper;
using Entities.Models;
using Entities.Requests;
using System;
using System.Globalization;

namespace ApiCsv.Utils
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {

            //_ = CreateMap<Sales, SalesRequest>().ReverseMap();

            _ = CreateMap<SalesRequest, Sales>()
                .ForMember(d => d.DealNumber, o => o.MapFrom(s => s.DealNumber))
                .ForMember(d => d.CustomerName, o => o.MapFrom(s => s.CustomerName))
                .ForMember(d => d.DealershipName, o => o.MapFrom(s => s.DealershipName))
                .ForMember(d => d.Vehicle, o => o.MapFrom(s => s.Vehicle))
                .ForMember(d => d.Price, o => o.MapFrom(s => s.Price))
                .ForMember(d => d.Date, o => 
                    o.MapFrom(s => DateTime.ParseExact(s.Date, "M/d/yyyy", new CultureInfo("en-US"), DateTimeStyles.None)));

        }
    }
}
