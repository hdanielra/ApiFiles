﻿using AutoMapper;
using Contracts;
using Entities.Models;
using Entities.Requests;
using Entities.Responses;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;





namespace ApiCsv.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesController : ControllerBase
    {
        public readonly IRepositoryManager _repositoryManager;

        private readonly IWebHostEnvironment _webHostEnvironment;

        private readonly IMapper _mapper;


        // ------------------------------------------------------------------------------------
        public SalesController(IRepositoryManager repositoryManager,
                               IWebHostEnvironment webHostEnvironment,
                                  IMapper mapper)
        {
            _repositoryManager = repositoryManager;
            _webHostEnvironment = webHostEnvironment;
            _mapper = mapper;
        }
        // ------------------------------------------------------------------------------------





        // ------------------------------------------------------------------------------------
        // GET: api/Sales
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var sales = await _repositoryManager.Sales.FindAll(false).ToListAsync();
                return Ok(sales);
            }
            catch (System.Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        // ------------------------------------------------------------------------------------






        // ------------------------------------------------------------------------------------
        // GET: api/Sales/Get2
        [Route("GetData")]
        [HttpGet]
        public async Task<IActionResult> GetData()
        {
            DataResponse dataResponse = new DataResponse();

            try
            {
                var sales = await _repositoryManager.Sales.FindAll(false).ToListAsync();
                
                dataResponse.Message = "Successfully! All records has been fetched.";
                dataResponse.Status = "Success";
                dataResponse.Data = sales;
                dataResponse.MostSold = GetBest();

                return Ok(dataResponse);
            }
            catch (System.Exception ex)
            {
                dataResponse.Message = "Error! " + ex.Message;
                dataResponse.Status = "Error";
                return BadRequest(dataResponse);
                //return BadRequest(ex.Message);
            }
        }
        // ------------------------------------------------------------------------------------





        // ------------------------------------------------------------------------------------
        // GET: api/Sales/5
        [HttpGet("{id}")]
        public async Task<ActionResult> Get(int Id)
        {
            var sale = await _repositoryManager.Sales
                        .FindByCondition(s => s.DealNumber.Equals(Id), false).FirstOrDefaultAsync();

            if (sale == null)
            {
                return BadRequest();
            }

            return Ok(sale);
        }
        // ------------------------------------------------------------------------------------








        // ------------------------------------------------------------------------------------
        // GET: api/Sales/GetBestSeller
        [Route("GetBestSeller")]
        [HttpGet]
        public async Task<ActionResult> GetBestSeller()
        {

            var bestSeller = await _repositoryManager.Sales.FindAll(false)
                                    .GroupBy(d => d.Vehicle)
                                    .Select(s => new
                                    {
                                        Vehicle = s.Key,
                                        Count = s.Count()
                                    })
                                    .OrderByDescending(x => x.Count)
                                    .FirstOrDefaultAsync();
            //var bestSeller = GetBest();



            if (bestSeller == null)
            {
                return BadRequest();
            }

            return Ok(bestSeller);
        }
        // ------------------------------------------------------------------------------------







         //------------------------------------------------------------------------------------
        private async Task<object> GetBest()
        {

            var bestSeller = await _repositoryManager.Sales.FindAll(false)
                                    .GroupBy(d => d.Vehicle)
                                    .Select(s => new
                                    {
                                        Vehicle = s.Key,
                                        Count = s.Count()
                                    })
                                    .OrderByDescending(x => x.Count)
                                    .FirstOrDefaultAsync();




            if (bestSeller == null)
            {
                return new
                {
                    Vehicle = "",
                    Count = 0
                };
            }

            return bestSeller;
        }
         //------------------------------------------------------------------------------------





        // ------------------------------------------------------------------------------------
        [Route("UploadFileCsv")]
        [HttpPost]
        public async Task<ActionResult> UploadFileCsv()
        {
            var httpRequest = Request.Form;


            IFormFile file = httpRequest.Files[0];


            #region Upload CSV

            string fileName = $"{_webHostEnvironment.ContentRootPath}\\FileStorage\\{file.FileName}";


            using (FileStream fileStream = System.IO.File.Create(fileName))
            {
                await file.CopyToAsync(fileStream);
                await fileStream.FlushAsync();
            }

            #endregion


            var sales = SaveSalesFromFile(fileName);
            return Ok(sales);

        }
        // ------------------------------------------------------------------------------------




        // ------------------------------------------------------------------------------------
        private ActionResult SaveSalesFromFile(string fileName)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;

            List<SalesRequest> salesRequest = new List<SalesRequest>();
            List<Sales> sales = new List<Sales>();

            Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");

            #region Read CSV

            var path = fileName;
            int count = 0;

            //Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            //var enc1252 = Encoding.GetEncoding(1252);
            var enc1252 = CodePagesEncodingProvider.Instance.GetEncoding(1252);

            using (var reader = new StreamReader(path, enc1252))
                while (!reader.EndOfStream)
                {
                    count++;

                    var line = reader.ReadLine();
                    //var values = line.Split(',');
                    var values = CSVParser.Split(line);

                    if (count == 1) continue;


                    SalesRequest saleRequest = new SalesRequest()
                    {
                        DealNumber = values[0].Replace("\"", ""),
                        CustomerName = values[1].Replace("\"", ""),
                        DealershipName = values[2].Replace("\"", ""),
                        Vehicle = values[3].Replace("\"", ""),
                        Price = values[4].Replace("\"", ""),
                        Date = values[5].Replace("\"", "")
                    };
                    salesRequest.Add(saleRequest);

                    // mapping
                    Sales sale = _mapper.Map<Sales>(saleRequest);
                    sales.Add(sale);

                    //// save in memory
                    //_repositoryManager.Sales.Create(sale);
                    //_repositoryManager.Save();
                }

            // save in memory
            _repositoryManager.Sales.CreateRange(sales);
            _repositoryManager.Save();


            #endregion

            var salesResponse = _repositoryManager.Sales.FindAll(false).ToList();

            return Ok(salesResponse);
        }
        // ------------------------------------------------------------------------------------

    }
}
