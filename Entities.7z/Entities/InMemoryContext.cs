﻿using Entities.Models;
using Microsoft.EntityFrameworkCore;

namespace Entities
{
    public class InMemoryContext : DbContext
    {
        public InMemoryContext(DbContextOptions<InMemoryContext> options) : base(options)
        {

        }


        public DbSet<Sales> Sales { get; set; }
        public DbSet<Files> Files { get; set; }

    }

}
